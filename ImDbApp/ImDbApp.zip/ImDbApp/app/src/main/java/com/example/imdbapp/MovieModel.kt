package com.example.imdbapp

data class MovieModel(val name: String = "", val count: Int = 0){
}