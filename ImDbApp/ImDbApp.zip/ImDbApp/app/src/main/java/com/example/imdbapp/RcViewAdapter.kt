package com.example.imdbapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RcViewAdapter(val userList: ArrayList<MovieModel>) : RecyclerView.Adapter<RcViewAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.layout_adapter, parent, false)
        return ViewHolder(v);
    }
    override fun getItemCount(): Int {
        return userList.size
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {


        holder.name.text = userList[position].name
        holder.count?.text = userList[position].count.toString()
    }

    inner class ViewHolder(itemView:View): RecyclerView.ViewHolder(itemView)
    {
        val name: TextView = itemView.findViewById<TextView>(R.id.tvName)
        val count = itemView.findViewById<TextView>(R.id.tvCount)

    }
}